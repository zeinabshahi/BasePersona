// components/WalletMetrics.tsx
import * as React from 'react'
import css from './frames.module.css'
import { useWallet } from '../hooks/useWallet'
import { adaptWallet } from '../lib/walletAdapter'
import type { UiMonth } from '../lib/walletAdapter'
import type { WalletDoc } from '../lib/typesWallet'

const fmt = (n?: number, d = 2) => (n == null || Number.isNaN(n) ? '—' : Number(n).toFixed(d))
function delta(a?: number, b?: number) {
  if (a == null || b == null) return { diff: null as number | null, pct: null as number | null }
  const diff = a - b
  const pct = b === 0 ? (a === 0 ? 0 : 100) : (diff / b) * 100
  return { diff, pct }
}
const ymToText = (ym: string) => {
  const [y, m] = ym.split('-').map(Number)
  const d = new Date(Date.UTC(y, m - 1, 1))
  return d.toLocaleString('en-US', { month: 'short', year: 'numeric', timeZone: 'UTC' })
}

/* spark */
type SparkProps = { series: number[]; labels: string[]; selected: number; onPointClick?: (i:number)=>void; color: string }
function Spark({ series, labels, selected, onPointClick, color }: SparkProps) {
  const w = 360, h = 96, pad = 10
  const n = series.length
  const xs = series.map((_, i) => pad + (n > 1 ? i * (w - pad * 2) / (n - 1) : 0))
  const max = Math.max(0.0001, ...series)
  const y = (v: number) => h - pad - (v / max) * (h - pad * 2)
  const d = xs.map((x, i) => `${i ? 'L' : 'M'}${x.toFixed(1)},${y(series[i]).toFixed(1)}`).join(' ')
  const area = `${d} L${xs[n-1]?.toFixed(1)||pad},${(h-pad).toFixed(1)} L${xs[0]?.toFixed(1)||pad},${(h-pad).toFixed(1)} Z`
  return (
    <div style={{ position: 'relative' }}>
      <svg viewBox={`0 0 ${w} ${h}`} className={css.spark} preserveAspectRatio="none" aria-label="spark">
        <path d={area} style={{ fill: color.replace('rgb','rgba').replace(')',',.16)') }} />
        <path d={d} style={{ stroke: color, strokeWidth: 2, fill: 'none' }} />
        {xs.map((x, i) => (
          <circle key={i} cx={x} cy={y(series[i])} r={selected === i ? 4 : 2}
                  className={selected === i ? css.dotSel : css.dot}
                  onClick={() => onPointClick?.(i)} />
        ))}
      </svg>
      <div style={{ display:'flex', justifyContent:'space-between', fontSize:11, color:'#98a2b3', marginTop:4 }}>
        <span>{labels[0] ?? ''}</span><span>{labels[labels.length-1] ?? ''}</span>
      </div>
    </div>
  )
}

/* demo */
function monthsRange(first: string, last: string) {
  const out: string[] = []
  const [fY, fM] = first.split('-').map(Number)
  const [lY, lM] = last.split('-').map(Number)
  let y = fY, m = fM
  while (y < lY || (y === lY && m <= lM)) { out.push(`${y}-${String(m).padStart(2,'0')}`); m++; if (m===13){m=1;y++} }
  return out
}
function buildDemoWalletDoc(): WalletDoc {
  const months: Record<string, any> = {}
  const ys = monthsRange('2023-07','2025-10')
  let seed = 3
  for (const ym of ys) {
    seed = (seed * 9301 + 49297) % 233280
    const r = (seed / 233280)
    months[ym] = {
      txs: Math.floor(100 + r*900),
      uniq: Math.floor(2 + r*8),
      trade: Math.floor(r*50),
      nft: r>0.85 ? 1 : 0,
      gas: +(0.001 + r*0.05).toFixed(6),
      bal: +(0.8 + r*5).toFixed(6),
      days: Math.min(31, Math.floor(10 + r*21)),
      spread: +(0.3 + r*0.7).toFixed(3),
      streak: Math.min(31, Math.floor(8 + r*23)),
      rank_m: Math.floor(5000 + r*50000),
      pct_m: +((r*0.05)).toFixed(6),
    }
  }
  return { wallet:'0x0', rank:999999, lifetime:{ months_active: ys.length, first:'2023-07', last:'2025-10', gas_sum:0, streak_best_days:120 }, months }
}

export default function WalletMetrics({
  address, selectedYm, onMonthsLoaded, onSelectionChange,
}: {
  address?: string
  selectedYm: number | null
  onMonthsLoaded?: (list: { ym: number; label: string }[]) => void
  onSelectionChange?: (ym: number) => void
}) {
  const [sel, setSel] = React.useState(0)
  const isAllTime = selectedYm == null
  const { data: wRemote, isLoading, error } = useWallet(address ? address.toLowerCase() : undefined)

  const demoDoc = React.useMemo<WalletDoc>(() => buildDemoWalletDoc(), [])
  const baseDoc = (wRemote ?? demoDoc) as any
  const doc = React.useMemo(() => (baseDoc?.monthsArr ? baseDoc : adaptWallet(baseDoc)), [baseDoc])

  const months = React.useMemo<UiMonth[]>(() => (doc ? doc.monthsArr : []), [doc])
  const last = Math.max(0, months.length - 1)

  const onMonthsLoadedRef = React.useRef(onMonthsLoaded)
  React.useEffect(() => { onMonthsLoadedRef.current = onMonthsLoaded }, [onMonthsLoaded])

  React.useEffect(() => {
    if (!months.length) return
    setSel(last)
    const opts = months.map(m => ({ ym: Number(m.ym.replace('-', '')), label: ymToText(m.ym) }))
    onMonthsLoadedRef.current?.(opts)
  }, [months, last])

  React.useEffect(() => {
    if (!months.length) return
    if (selectedYm == null) { setSel(last); return }
    const idx = months.findIndex(m => Number(m.ym.replace('-', '')) === selectedYm)
    if (idx >= 0) setSel(idx)
  }, [selectedYm, months, last])

  const cur  = months[sel]
  const prev = months[sel - 1]
  const labels = months.map(m => ymToText(m.ym))

  const s = {
    bal:   months.map(m => m.bal   || 0),
    trade: months.map(m => m.trade || 0),
    txs:   months.map(m => m.txs   || 0),
    uniq:  months.map(m => m.uniq  || 0),
    days:  months.map(m => m.days  || 0),
    strk:  months.map(m => m.streak|| 0),
    gas:   months.map(m => m.gas   || 0),
    nft:   months.map(m => m.nft   || 0),
    rank:  months.map(m => m.rank_m|| 0),
  }
  const sum = (arr:number[]) => arr.reduce((a,b)=>a+(b||0),0)
  const nonZeroBal = s.bal.filter(v => v > 0)
  const balanceAvg = (nonZeroBal.length ? sum(nonZeroBal)/nonZeroBal.length : sum(s.bal)/Math.max(1,s.bal.length))
  const gasTotal = (doc?.gasTotalEth ?? (doc?.lifetime?.gas_sum_filled ?? doc?.lifetime?.gas_sum ?? sum(s.gas)))
  const bestStreakAll = (doc?.bestStreakDays ?? Math.max(0,...s.strk))

  const V = {
    bal:    isAllTime ? balanceAvg    : cur?.bal,
    trade:  isAllTime ? sum(s.trade)  : cur?.trade,
    txs:    isAllTime ? sum(s.txs)    : cur?.txs,
    uniq:   isAllTime ? sum(s.uniq)   : cur?.uniq,
    days:   isAllTime ? sum(s.days)   : cur?.days,
    streak: isAllTime ? bestStreakAll : cur?.streak,  // ← ماهانه مثل قبل
    gas:    isAllTime ? gasTotal      : cur?.gas,
    nft:    isAllTime ? sum(s.nft)    : cur?.nft,
    rank:   isAllTime ? (doc?.rank ?? null) : cur?.rank_m,
    pct_m:  isAllTime ? null : cur?.pct_m,
  }

  const dBal   = isAllTime ? { diff:null,pct:null } : delta(cur?.bal,    prev?.bal)
  const dTrade = isAllTime ? { diff:null,pct:null } : delta(cur?.trade,  prev?.trade)
  const dTxs   = isAllTime ? { diff:null,pct:null } : delta(cur?.txs,    prev?.txs)
  const dUniq  = isAllTime ? { diff:null,pct:null } : delta(cur?.uniq,   prev?.uniq)
  const dDays  = isAllTime ? { diff:null,pct:null } : delta(cur?.days,   prev?.days)
  const dStrk  = isAllTime ? { diff:null,pct:null } : delta(cur?.streak, prev?.streak)
  const dGas   = isAllTime ? { diff:null,pct:null } : delta(cur?.gas,    prev?.gas)
  const dNft   = isAllTime ? { diff:null,pct:null } : delta(cur?.nft,    prev?.nft)

  const banner = (address && isLoading)
    ? <div className={css.error} style={{ marginBottom: 8 }}>Loading…</div>
    : (address && error)
      ? <div className={css.error} style={{ marginBottom: 8 }}>
          {String((error as any)?.message || 'Fetch error')} — showing demo.
        </div>
      : null

  const clickMonth = (i:number) => {
    const idx = Math.max(0, Math.min(i, months.length - 1))
    setSel(idx)
    onSelectionChange?.(Number(months[idx].ym.replace('-', '')))
  }

  return (
    <div className={css.wrap}>
      {banner}
      <div className={css.topinfo}>
        <div>Month: <strong>{isAllTime ? 'ALL' : (cur?.ym || '—')}</strong></div>
        <div className={css.badge}>Best Streak: {bestStreakAll} days</div>
      </div>

      <div className={css.grid}>
        <div className={css.card}>
          <div className={css.head}><div className={css.title}>Balance (ETH)</div></div>
          <div className={css.row}>
            <div className={css.big}>{fmt(V.bal, 3)}</div>
            <div className={css.sub}>{isAllTime ? 'all-time average' : 'on-chain (avg)'}</div>
            <div className={css.delta}>{dBal.diff==null?'—':fmt(dBal.diff,3)} <span className={css.muted}>({dBal.pct==null?'—':fmt(dBal.pct,1)+'%'})</span></div>
          </div>
          <Spark series={s.bal} labels={labels} selected={sel} onPointClick={clickMonth} color='rgb(37,99,235)' />
        </div>

        <div className={css.card}>
          <div className={css.head}><div className={css.title}>Trades (count)</div></div>
          <div className={css.row}>
            <div className={css.big}>{fmt(V.trade, 0)}</div>
            <div className={css.sub}>{isAllTime ? 'all-time sum' : 'swap/trade tx count'}</div>
            <div className={css.delta}>{dTrade.diff==null?'—':fmt(dTrade.diff,0)} <span className={css.muted}>({dTrade.pct==null?'—':fmt(dTrade.pct,1)+'%'})</span></div>
          </div>
          <Spark series={s.trade} labels={labels} selected={sel} onPointClick={clickMonth} color='rgb(16,185,129)' />
        </div>

        <div className={css.card}>
          <div className={css.head}><div className={css.title}>Transactions</div></div>
          <div className={css.row}>
            <div className={css.big}>{fmt(V.txs, 0)}</div>
            <div className={css.sub}>{isAllTime ? 'all-time sum' : 'txs per month'}</div>
            <div className={css.delta}>{dTxs.diff==null?'—':fmt(dTxs.diff,0)} <span className={css.muted}>({dTxs.pct==null?'—':fmt(dTxs.pct,1)+'%'})</span></div>
          </div>
          <Spark series={s.txs} labels={labels} selected={sel} onPointClick={clickMonth} color='rgb(59,130,246)' />
        </div>

        <div className={css.card}>
          <div className={css.head}><div className={css.title}>Unique Contracts</div></div>
          <div className={css.row}>
            <div className={css.big}>{fmt(V.uniq, 0)}</div>
            <div className={css.sub}>{isAllTime ? 'all-time sum' : 'per month'}</div>
            <div className={css.delta}>{dUniq.diff==null?'—':fmt(dUniq.diff,0)} <span className={css.muted}>({dUniq.pct==null?'—':fmt(dUniq.pct,1)+'%'})</span></div>
          </div>
          <Spark series={s.uniq} labels={labels} selected={sel} onPointClick={clickMonth} color='rgb(234,179,8)' />
        </div>

        <div className={css.card}>
          <div className={css.head}><div className={css.title}>Active Days</div></div>
          <div className={css.row}>
            <div className={css.big}>{fmt(V.days, 0)}</div>
            <div className={css.sub}>{isAllTime ? 'all-time sum' : 'per month'}</div>
            <div className={css.delta}>{dDays.diff==null?'—':fmt(dDays.diff,0)} <span className={css.muted}>({dDays.pct==null?'—':fmt(dDays.pct,1)+'%'})</span></div>
          </div>
          <Spark series={s.days} labels={labels} selected={sel} onPointClick={clickMonth} color='rgb(168,85,247)' />
        </div>

        <div className={css.card}>
          <div className={css.head}><div className={css.title}>Best Streak (days)</div></div>
          <div className={css.row}>
            <div className={css.big}>{fmt(V.streak, 0)}</div>
            <div className={css.sub}>{isAllTime ? 'best over all months' : 'within month'}</div>
            <div className={css.delta}>{dStrk.diff==null?'—':fmt(dStrk.diff,0)} <span className={css.muted}>({dStrk.pct==null?'—':fmt(dStrk.pct,1)+'%'})</span></div>
          </div>
          <Spark series={s.strk} labels={labels} selected={sel} onPointClick={clickMonth} color='rgb(250,204,21)' />
        </div>

        <div className={css.card}>
          <div className={css.head}><div className={css.title}>Gas Paid (ETH)</div></div>
          <div className={css.row}>
            <div className={css.big}>{fmt(V.gas, 6)}</div>
            <div className={css.sub}>{isAllTime ? 'all-time sum' : 'this month'}</div>
            <div className={css.delta}>{dGas.diff==null?'—':fmt(dGas.diff,6)} <span className={css.muted}>({dGas.pct==null?'—':fmt(dGas.pct,1)+'%'})</span></div>
          </div>
          <Spark series={s.gas} labels={labels} selected={sel} onPointClick={clickMonth} color='rgb(239,68,68)' />
        </div>

        <div className={css.card}>
          <div className={css.head}><div className={css.title}>NFT (count)</div></div>
          <div className={css.row}>
            <div className={css.big}>{fmt(V.nft, 0)}</div>
            <div className={css.sub}>{isAllTime ? 'all-time sum' : 'per month'}</div>
            <div className={css.delta}>{dNft.diff==null?'—':fmt(dNft.diff,0)} <span className={css.muted}>({dNft.pct==null?'—':fmt(dNft.pct,1)+'%'})</span></div>
          </div>
          <Spark series={s.nft} labels={labels} selected={sel} onPointClick={clickMonth} color='rgb(20,184,166)' />
        </div>

        <div className={css.card}>
          <div className={css.head}><div className={css.title}>{isAllTime ? 'Global Rank' : 'Monthly Rank'}</div></div>
          <div className={css.row}>
            <div className={css.big}>
              {isAllTime
                ? (V.rank != null ? `#${Number(V.rank).toLocaleString()}` : '—')
                : (cur?.rank_m != null ? `#${cur.rank_m.toLocaleString?.()}` : '—')}
            </div>
            <div className={css.sub}>
              {isAllTime ? 'overall' : `better is lower • ${(cur?.pct_m ?? 0) * 100 < 0.01 ? '<0.01' : fmt((cur?.pct_m ?? 0) * 100, 2)}%`}
            </div>
            <div className={css.delta}>—</div>
          </div>
          <Spark series={s.rank.map(v => (v > 0 ? 1 / v : 0))} labels={labels} selected={sel} onPointClick={clickMonth} color='rgb(107,114,128)' />
        </div>
      </div>
    </div>
  )
}
