# Base Persona UI

این ریپو رابط کاربری و APIهای پروژهٔ «Base Persona» را پیاده‌سازی می‌کند. هدف این سیستم تولید یک NFT شخصیت منحصر‌به‌فرد بر اساس فعالیت‌های کیف‌پول در شبکهٔ Base است. فرانت‌اند با Next.js نوشته شده و از Web3Modal + wagmi + viem برای اتصال کیف‌پول استفاده می‌کند. بدون RainbowKit طراحی شده تا کنترل بیشتری روی تجربهٔ کاربر داشته باشیم.

## نصب وابستگی‌ها

در ریشهٔ ریپو دستور زیر را اجرا کنید تا تمام بسته‌ها نصب شوند:

```powershell
npm ci
```

## اجرای حالت توسعه

برای اجرای محیط توسعه و مشاهدهٔ سایت در مرورگر:

```powershell
npm run dev
# سپس مرورگر را به http://localhost:3000 هدایت کنید
```

## تنظیم متغیرهای محیطی

یک فایل `.env` از نمونهٔ موجود بسازید و مقادیر لازم را تعیین کنید. این متغیرها شامل آدرس قرارداد، مشخصات کیف‌پول کانکت (WalletConnect)، RPC، کلید خصوصی سرور برای امضا، کلید Arweave، توکن IPFS و مدل AI است.

```powershell
Copy-Item .\.env.example .\.env
notepad .\.env   # متغیرها را تنظیم کنید
```

- `NEXT_PUBLIC_CONTRACT` را با آدرس قرارداد دیپلوی‌شده در ریپوی کانترکت‌ها جایگزین کنید.
- `PRIVATE_KEY` فقط برای امضای سرور استفاده می‌شود (sign‑mint) و هرگز نباید افشا شود.

## ساخت و استقرار در Railway

برای ساخت پروژه در محیط تولید و اجرای آن روی Railway، از دستورات زیر استفاده کنید. Railway مقدار `PORT` را در زمان اجرا تعیین می‌کند؛ برنامه باید این متغیر را بخواند و از آن استفاده کند.

```powershell
npm ci && npm run build
$env:PORT=$env:PORT
npm start
```

## ساختار پوشه‌ها

- **`pages/api`**: شامل همهٔ endpointهای سرور است: health، stats، persona، traits، narrative، generate، job، sign‑mint، frame.
- **`pages/index.tsx`**: کامپوننت Stepper که جریان «اتصال → تحلیل → پرسونـا و روایت → تولید → پیش‌نمایش → امضا» را پیاده می‌کند.
- **`pages/frames/[id].tsx`** و **`pages/api/frame`**: نمونه‌ای از مسیری که اطلاعات Frame برای Farcaster را فراهم می‌کند.
- **`pages/miniapp.tsx`**: یک iframe ساده برای مینی‌اپ Base که UI اصلی را درون خود بارگذاری می‌کند.
- **`lib/ui.css`**: استایل‌ها.
- **`lib/wallet.ts`**: پیکربندی wagmi/Web3Modal.
- **`lib/utils.ts`**: توابع کمکی مثل مرتب‌سازی JSON و keccak256.
- **`lib/abi/ActivityPersona.json`**: ABI قرارداد ActivityPersona. آن را از ریپوی کانترکت‌ها کپی کرده‌ایم تا متدهای قرارداد در فرانت‌اند قابل استفاده شوند.

## محدودیت‌ها

این پیاده‌سازی برای نمونه است و بعضی ویژگی‌های توصیف شده در Master Project Prompt را به‌طور کامل پوشش نمی‌دهد. از جمله:

- محاسبهٔ دقیق metrics و percentileها در `stats.ts` (در حال حاضر یک مقدار ثابت برمی‌گرداند).
- ایجاد تصویر AI و آپلود آن در Arweave/IPFS (تابع `generate` و `job` فقط شناسهٔ ساختگی برمی‌گرداند).
- محاسبهٔ قیمت USD و ویژگی USD_PEGGED در sign‑mint.
- دسترسی کامل به Farcaster Frame و Base Mini App؛ این فایل‌ها نمونه و محدود هستند.

توسعهٔ کامل این بخش‌ها نیازمند پیاده‌سازی منطق اضافی یا اتصال به سرویس‌های خارجی است. با این وجود، این کد نقطهٔ شروع مناسبی برای پیاده‌سازی پروژهٔ «Base Persona» است.



## Patch Notes (Auto-fix)
- Avoided MetaMask SDK bundle by importing connectors from subpaths:
  `@wagmi/connectors/injected` and `@wagmi/connectors/walletConnect`.
- Robust LLM/Image helpers with timeouts, safe fallbacks and per-request overrides.
- `.env.local` keys completed (LLM/IMG/providers, timeouts, WalletConnect).
- No changes needed to Next.js config.
#   B a s e P e r s o n a  
 