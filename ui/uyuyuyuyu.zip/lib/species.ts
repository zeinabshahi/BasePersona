// lib/species.ts
import { toKeccakHex } from './utils';

export type SpeciesId = 'fox' | 'dolphin' | 'owl' | 'panda';

export const SPECIES: Record<
  SpeciesId,
  {
    title: string;
    imageCue: string;         // used only for image assembly wording if needed
    personaFlavors: string[]; // tone hooks for narrative generation
  }
> = {
  fox: {
    title: 'Fox',
    imageCue: 'sleek cyber-fox with Base-native flair',
    personaFlavors: ['curious', 'light-footed', 'opportunistic', 'playfully strategic'],
  },
  dolphin: {
    title: 'Dolphin',
    imageCue: 'agile cyber-dolphin with calm precision',
    personaFlavors: ['steady', 'cooperative', 'signal-seeking', 'patient'],
  },
  owl: {
    title: 'Owl',
    imageCue: 'focused cyber-owl with analytic poise',
    personaFlavors: ['observant', 'pattern-first', 'night-active', 'measured'],
  },
  panda: {
    title: 'Panda',
    imageCue: 'confident cyber-panda with grounded strength',
    personaFlavors: ['even-tempered', 'decisive when needed', 'builder-friendly', 'resilient'],
  },
};

// 16 buckets by first hex nibble after "0x" → 4 animals.
// 0..3: dolphin, 4..7: fox (includes '6'), 8..b: owl, c..f: panda
const NIBBLE_TO_SPECIES: Record<string, SpeciesId> = {
  '0': 'dolphin', '1': 'dolphin', '2': 'dolphin', '3': 'dolphin',
  '4': 'fox',     '5': 'fox',     '6': 'fox',     '7': 'fox',
  '8': 'owl',     '9': 'owl',     'a': 'owl',     'b': 'owl',
  'c': 'panda',   'd': 'panda',   'e': 'panda',   'f': 'panda',
};

export function pickSpeciesByNibble(address?: string): SpeciesId {
  const a = (address || '').toLowerCase();
  const nib = /^0x[0-9a-f]{1,}/.test(a) ? a[2] : undefined;
  if (nib && NIBBLE_TO_SPECIES[nib]) return NIBBLE_TO_SPECIES[nib];
  // rare fallback
  const seedHex = toKeccakHex(a || '0xdead');
  const idx = Number(BigInt(seedHex) % 4n);
  return (['fox', 'dolphin', 'owl', 'panda'] as SpeciesId[])[idx];
}
