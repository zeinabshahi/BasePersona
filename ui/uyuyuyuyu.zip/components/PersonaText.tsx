// components/PersonaText.tsx
import React from 'react';

type PersonaCopy = {
  title?: string;
  oneLiner?: string;
  summary?: string;
  highlights?: string[];
  personalityTags?: string[];
};

function escapeHtml(s: string) {
  return s.replace(/[&<>"']/g, (c) =>
    ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'} as any)[c]
  );
}

// Allow only <b> and <i>, everything else escaped.
function sanitize(text?: string) {
  if (!text) return '';
  const esc = escapeHtml(text);
  return esc
    .replace(/&lt;b&gt;/g, '<b>')
    .replace(/&lt;\/b&gt;/g, '</b>')
    .replace(/&lt;i&gt;/g, '<i>')
    .replace(/&lt;\/i&gt;/g, '</i>');
}

export function PersonaText({ narrative, isLoading }: { narrative?: any, isLoading?: boolean }) {
  if (isLoading) {
    return <div style={{opacity:.7}}>Analyzing…</div>;
  }
  const src: PersonaCopy = narrative?.narrativeJson || narrative?.personaJson || narrative || {};
  const title = src.title || 'Onchain Persona';
  const oneLiner = sanitize(src.oneLiner || '');
  const summary = sanitize(src.summary || '');
  const highlights = Array.isArray(src.highlights) ? src.highlights : [];

  return (
    <div>
      <div style={{fontWeight:700, fontSize:18, marginBottom:8}}>{title}</div>
      {oneLiner && (
        <p dangerouslySetInnerHTML={{ __html: oneLiner }} style={{margin:'6px 0'}} />
      )}
      {summary && (
        <p dangerouslySetInnerHTML={{ __html: summary }} style={{margin:'10px 0 6px 0'}} />
      )}
      {highlights.length > 0 && (
        <div style={{marginTop:10}}>
          <div style={{fontWeight:600, marginBottom:6}}>Highlights:</div>
          <ul style={{margin:0, paddingLeft:16}}>
            {highlights.map((h, i) => <li key={i}>{h}</li>)}
          </ul>
        </div>
      )}
    </div>
  );
}

export default PersonaText;
