// pages/api/generate.ts
import type { NextApiRequest, NextApiResponse } from 'next';
import path from 'path';
import fs from 'fs/promises';
import sharp from 'sharp';
import { pickSpeciesByNibble } from '../../lib/species';

async function exists(p: string) { try { await fs.access(p); return true; } catch { return false; } }

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') return res.status(405).json({ ok:false, error:'method_not_allowed' });
  try {
    const { address, traitsJson } = req.body || {};
    const addr = String(address || '');
    if (!/^0x[0-9a-fA-F]{40}$/.test(addr)) return res.status(400).json({ ok:false, error:'bad_address' });

    const species = traitsJson?.species || pickSpeciesByNibble(addr);
    const proj    = process.cwd();
    const basePng = path.join(proj, 'public', 'assets', 'animals', species, 'base.png');

    if (!(await exists(basePng))) {
      return res.status(500).json({ ok:false, error:`base_png_missing_for_${species}` });
    }

    // Start with animal base at 1024x1024
    let img = sharp(basePng).resize(1024, 1024, { fit: 'cover' });
    const overlays: sharp.OverlayOptions[] = [];

    // Optional overlays from traits
    const tier  = Number(traitsJson?.tier ?? 0);
    const stage = String(traitsJson?.stage || 'adult');
    const og    = !!traitsJson?.badges?.og;

    const ringPath  = path.join(proj, 'public', 'assets', 'overlays', 'rings',  `tier_${Math.max(0, Math.min(4, tier))}.png`);
    const badgePath = path.join(proj, 'public', 'assets', 'overlays', 'badges', 'og.png');
    const stagePath = path.join(proj, 'public', 'assets', 'overlays', 'stage',  (stage === 'elder_powerful' ? 'elder.png' : 'adult.png'));

    if (await exists(ringPath))  overlays.push({ input: ringPath, top: 0, left: 0 });
    if (og && await exists(badgePath)) overlays.push({ input: badgePath, top: 32, left: 32 });
    if (await exists(stagePath)) overlays.push({ input: stagePath, top: 0, left: 0 });

    if (overlays.length) img = img.composite(overlays);

    const out = await img.png({ compressionLevel: 9 }).toBuffer();
    const b64 = out.toString('base64');
    return res.status(200).json({ ok: true, imageURL: `data:image/png;base64,${b64}`, providerUsed: 'assembler', promptUsed: 'locked/animal-base', size: '1024x1024' });
  } catch (e: any) {
    return res.status(500).json({ ok:false, error: e?.message || 'generate_failed' });
  }
}
