// pages/api/narrative.ts
import type { NextApiRequest, NextApiResponse } from 'next';
import { pickSpeciesByNibble, SpeciesId, SPECIES } from '../../lib/species';

type PersonaIn = {
  persona?: any;
  traits?: any;
  address?: string;
};

function toHexSeed(addr?: string) {
  try {
    const a = (addr || '').toLowerCase();
    if (!/^0x[0-9a-f]{40}$/.test(a)) return 12345;
    return parseInt(a.slice(-8), 16) || 12345;
  } catch { return 12345 }
}

// mulberry32 PRNG
function mulberry32(seed: number) {
  let t = seed >>> 0;
  return () => {
    t += 0x6D2B79F5;
    let r = Math.imul(t ^ (t >>> 15), 1 | t);
    r ^= r + Math.imul(r ^ (r >>> 7), 61 | r);
    return ((r ^ (r >>> 14)) >>> 0) / 4294967296;
  };
}

function pick<T>(rng: () => number, arr: T[]): T {
  return arr[Math.floor(rng() * arr.length)];
}

function normalizeArchetype(p?: any): 'Explorer'|'Builder'|'Generalist'|'Degen'|'Collector'|'Quiet' {
  const t = (p?.archetype || p?.traitsText?.[0] || '').toLowerCase();
  if (t.includes('degen')) return 'Degen';
  if (t.includes('builder') || (p?.tone === 'builderish')) return 'Builder';
  if (t.includes('collector')) return 'Collector';
  if (t.includes('explorer')) return 'Explorer';
  if (t.includes('generalist')) return 'Generalist';
  return 'Quiet';
}

function rankBand(p?: any): 'apex'|'elite'|'upper'|'mid'|'lower'|'fresh'|'unknown' {
  const band = (p?.rank?.band || '').toLowerCase();
  if (band.includes('apex')) return 'apex';
  if (band.includes('elite')) return 'elite';
  if (band.includes('trail') || band.includes('veteran')) return 'upper';
  if (band.includes('seasoned') || band.includes('explorer')) return 'mid';
  if (band.includes('casual')) return 'lower';
  if (band.includes('newcomer')) return 'fresh';
  return 'unknown';
}

function baseLines(rng: () => number) {
  const openers = [
    'On Base, summer never ends—it just shifts tempo.',
    'Some wallets shout; this one hums. On Base, that’s a flex.',
    'Builders keep shipping; this wallet acts like it got the memo.',
    'In a chain that rewards signal over noise, this presence is steady.',
  ];
  const culture = [
    'believes in “everyone can build” and actually does',
    'cares more about shipping than trending',
    'treats onchain identity as a verb, not a banner',
    'shows up when timelines cool off—and that’s where it wins',
  ];
  const tempo = [
    'waits for setups, then moves with clean intent',
    'ignores drama, respects risk, and plays for asymmetric edges',
    'reads flows, not slogans',
    'keeps the long game in view even on short days',
  ];
  return { opener: pick(rng, openers), culture: pick(rng, culture), tempo: pick(rng, tempo) };
}

function oneLiner(species: SpeciesId, band: string, arch: string) {
  const tag: Record<SpeciesId,string> = {
    fox:     'quick-thinking with smart entries',
    dolphin: 'calm precision and cooperative instincts',
    owl:     'observant, pattern-first decision making',
    panda:   'grounded strength with measured timing',
  };
  const lane = arch === 'Quiet' ? 'Explorer' : arch;
  const tier = band === 'unknown' ? 'midfield' : band.toLowerCase();
  return `Base-native ${species} energy — ${tag[species]}. ${lane} feel, ${tier} tier.`;
}

function craftStory(rng: () => number, params: {
  species: SpeciesId; band: ReturnType<typeof rankBand>; arch: ReturnType<typeof normalizeArchetype>;
}) {
  const { species, band, arch } = params;
  const lines = baseLines(rng);

  const titlePool: Record<ReturnType<typeof rankBand>, string[]> = {
    apex:   ['Base Apex', 'North-Star Runner', 'Prime Signal'],
    elite:  ['Blue-Chip Tempo', 'Core Builder', 'Prime Time'],
    upper:  ['Steady Trailblazer', 'Builder in Motion', 'Early Signal'],
    mid:    ['Quiet Voltage', 'Midfield Explorer', 'Halo Runner'],
    lower:  ['Sandbox Walker', 'Low-Freq Scout', 'Idle Dreamer'],
    fresh:  ['New Wave', 'First Steps', 'On-Ramp Soul'],
    unknown:['Onchain Native', 'Base-Side Wanderer', 'Signal in Progress'],
  };
  const title = pick(rng, titlePool[band]);

  const lane = arch === 'Quiet' ? 'explorer' : arch.toLowerCase();

  // ~150–220 words, human, Base-aware, no visual keywords
  const para: string[] = [];
  para.push(`${lines.opener} This wallet reads like someone who ${lines.tempo}.`);
  para.push(`There’s a ${lane} streak here—curiosity without chaos, focus without fuss. When markets shout, it edits; when opportunity whispers, it listens. The wins aren’t fireworks; they’re clean commits.`);
  para.push(`It shows that Base isn’t just cheaper blockspace—it’s a culture. This presence ${lines.culture}, keeps receipts in the activity log, and lets outcomes do the talking. Not a loud maxxer; more of a patient one who knows timing beats volume.`);
  para.push(`Think ${species} if you need a metaphor: habits that compound, timing that feels learned, and a way of moving that other wallets notice twice—once on entry, once when the merge request lands. Call it ${band !== 'unknown' ? `a ${band} presence` : 'a quiet constant'} on Base: independent taste, builder’s patience, and a nose for flow.`);

  const highlights = [
    pick(rng, [
      'cadence: slow build, clean exits',
      'cadence: bursts, then breathers',
      'cadence: quiet most days, decisive on the right ones',
    ]),
    pick(rng, [
      'risk lens: measured; prefers asymmetric edges',
      'risk lens: playful, not reckless',
      'risk lens: thesis-first, timing-aware',
    ]),
    pick(rng, [
      'community: ships more than it shouts',
      'community: Base-native and culture-aware',
      'community: shows up when timelines cool off',
    ]),
  ];

  return {
    title,
    oneLiner: oneLiner(species, band, arch),
    summary: para.join(' '),
    highlights,
    personalityTags: [], // no tags per your request
  };
}

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'method_not_allowed' });
  try {
    const { persona, traits, address }: PersonaIn = req.body || {};
    const seed = toHexSeed(address);
    const rng  = mulberry32(seed);

    const arch   = normalizeArchetype(persona);
    const band   = rankBand(persona);
    const species: SpeciesId = pickSpeciesByNibble(address);

    const story = craftStory(rng, { species, band, arch });
    return res.status(200).json({ narrativeJson: story });
  } catch (e: any) {
    return res.status(500).json({ error: e?.message || 'narrative_failed' });
  }
}
