// lib/species.ts
export const ALLOWED_SPECIES = ['fox','owl','wolf','orca','frog'] as const;
export type Species = typeof ALLOWED_SPECIES[number];

/** Deterministic pick from address (or allow safe override). */
export function speciesFromAddress(addr?: string, override?: string): Species {
  const ov = (override || '').toLowerCase();
  if ((ALLOWED_SPECIES as readonly string[]).includes(ov)) return ov as Species;
  const a = (addr || '').toLowerCase();
  // simple stable hash → index 0..4
  let h = 0 >>> 0;
  for (let i = 2; i + 1 < a.length; i += 2) {
    const b = parseInt(a.slice(i, i + 2), 16);
    if (Number.isFinite(b)) h = ((h * 33) ^ b) >>> 0;
  }
  return ALLOWED_SPECIES[h % ALLOWED_SPECIES.length];
}
