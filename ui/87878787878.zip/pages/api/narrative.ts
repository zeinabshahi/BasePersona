// pages/api/narrative.ts
import type { NextApiRequest, NextApiResponse } from 'next'
import { speciesFromAddress, ALLOWED_SPECIES, Species } from '../../lib/species'

type PersonaIn = {
  persona?: any
  traits?: any
  address?: string
  species?: string
}

function toSeed(addr?: string) {
  const a = (addr || '').toLowerCase()
  if (!/^0x[0-9a-f]{40}$/.test(a)) return 12345
  return parseInt(a.slice(-8), 16) || 12345
}
function mulberry32(seed: number) {
  let t = seed >>> 0
  return () => {
    t += 0x6D2B79F5
    let r = Math.imul(t ^ (t >>> 15), 1 | t)
    r ^= r + Math.imul(r ^ (r >>> 7), 61 | r)
    return ((r ^ (r >>> 14)) >>> 0) / 4294967296
  }
}
function pick<T>(rng: () => number, arr: T[], def?: T) {
  if (!arr.length) return def as T
  return arr[Math.floor(rng() * arr.length)]
}

function normBand(p?: any): 'apex'|'elite'|'upper'|'mid'|'lower'|'fresh'|'unknown' {
  const band = (p?.rank?.band || '').toLowerCase()
  if (band.includes('apex')) return 'apex'
  if (band.includes('elite')) return 'elite'
  if (band.includes('trail') || band.includes('veteran')) return 'upper'
  if (band.includes('seasoned') || band.includes('explorer')) return 'mid'
  if (band.includes('casual')) return 'lower'
  if (band.includes('newcomer')) return 'fresh'
  return 'unknown'
}

const TITLE_POOL: Record<Species, string[]> = {
  fox:  ['Fox Runner', 'Fox Scout', 'Fox Signal'],
  owl:  ['Owl Watcher', 'Owl Scribe', 'Owl Keeper'],
  wolf: ['Wolf Strider', 'Wolf Scout', 'Wolf Echo'],
  orca: ['Orca Voyager', 'Orca Current', 'Orca Pilot'],
  frog: ['Frog Hopper', 'Frog Leap', 'Frog Current'],
}

function baseFlavor(rng: () => number) {
  const open = [
    'On Base, summer doesn’t end—it just changes tempo.',
    'Base is builder country; the silence here is the sound of shipping.',
    'Some shout to be seen; on Base, getting things done is how you show up.',
  ]
  const ethos = [
    'name-first, chain-first, and unapologetically onchain',
    'less farm, more flow—less hype, more commits',
    'identity is earned here by moving things forward',
  ]
  return { opener: pick(rng, open), ethos: pick(rng, ethos) }
}

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'method_not_allowed' })
  try {
    const { persona, traits, address, species: speciesOverride }: PersonaIn = req.body || {}
    const addr = String(address || '').toLowerCase()
    const seed = toSeed(addr)
    const rng  = mulberry32(seed)

    // unify species across text+image
    const species =
      (traits?.traitsJson?.species as Species) ||
      speciesFromAddress(addr, speciesOverride)

    // clamp to allowed set, just in case
    const safeSpecies = (ALLOWED_SPECIES as readonly string[]).includes(species as string) ? species as Species : 'fox'

    const band = normBand(persona)
    const title = pick(rng, TITLE_POOL[safeSpecies])

    // one-liners (community-friendly, no visuals)
    const oneLiners = [
      `${title}: low noise, high signal.`,
      `${title}: watches first, ships second.`,
      `${title}: here for flow, not fanfare.`,
      `${title}: less drama, more doing.`,
    ]
    const oneLiner = pick(rng, oneLiners)

    const { opener, ethos } = baseFlavor(rng)

    // ~150-200 words; horoscopey, Base-toned, non-visual
    const paras: string[] = []
    paras.push(`${opener} This wallet reads like someone who shows up when timelines quiet down and the work begins. Not the loud kind—**the effective kind**. If there’s a pattern worth leaning into, it finds the edges, runs a small test, and scales only when the picture sharpens.`)
    paras.push(`There’s a ${band === 'apex' || band === 'elite' ? 'decisive' : band === 'upper' ? 'seasoned' : band === 'mid' ? 'curious' : 'patient'} streak here. The ${safeSpecies} spirit fits: alert, light on its feet, and stubborn about learning. Noise is not ignored—just sorted. When a chance opens, it moves like it already did the homework.`)
    paras.push(`People who vibe with Base get this rhythm: ${ethos}. You won’t always see the prep, but you tend to notice the merge. If two routes look the same, this one picks the cleaner one—the route with fewer witnesses and better odds.`)
    paras.push(`Today’s nudge: finish one small thing beautifully; say no to one shiny extra. Keep the timeline calm and the intent loud. The scoreboard will catch up.`)

    const narrativeJson = {
      title,
      oneLiner,
      summary: paras.join(' '),
      highlights: [
        'Works at a human pace—no rushing, no drifting.',
        'Tests small; commits when the picture sharpens.',
        'Believes identity belongs onchain; shows it by shipping.',
      ],
    }
    res.status(200).json({ narrativeJson })
  } catch (e: any) {
    res.status(500).json({ error: e?.message || 'narrative_failed' })
  }
}
