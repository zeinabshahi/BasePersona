import { memo } from 'react';

type PersonaCopy = {
  title?: string;
  oneLiner?: string;
  summary?: string;
  highlights?: string[];
};

type Props = {
  narrative?: PersonaCopy | { narrativeJson?: PersonaCopy; personaJson?: PersonaCopy } | null;
  isLoading?: boolean;
};

function sanitizeToHtml(input?: string): string {
  if (!input) return '';
  let s = input.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  s = s.replace(/\*\*(.+?)\*\*/g, '<b>$1</b>');                 // **bold**
  s = s.replace(/&lt;b&gt;(.+?)&lt;\/b&gt;/g, '<b>$1</b>');      // allow manual <b>..</b>
  s = s.replace(/\r\n|\r|\n/g, '<br/>');                         // line breaks
  return s;
}
function RichText({ text }: { text?: string }) {
  return <span dangerouslySetInnerHTML={{ __html: sanitizeToHtml(text) }} />;
}

function Skeleton() {
  const Bar = ({ w }: { w: string }) => (
    <div style={{ height: 10, width: w, background: '#eef2f7', borderRadius: 6, marginBottom: 8 }} />
  );
  return (
    <div aria-busy="true" aria-live="polite">
      <Bar w="50%" /><Bar w="92%" /><Bar w="88%" /><Bar w="70%" /><Bar w="40%" />
    </div>
  );
}

const PersonaTextBase = ({ narrative, isLoading }: Props) => {
  const src: PersonaCopy | undefined =
    (narrative as any)?.narrativeJson ??
    (narrative as any)?.personaJson ??
    (narrative as any) ??
    undefined;

  if (isLoading && !src) return <Skeleton />;

  const title = src?.title ?? 'Onchain Persona';
  const oneLiner = src?.oneLiner ?? 'Quiet voltage with builder instincts.';
  const summary =
    src?.summary ??
    'Reads the room before it moves. Curious on signal, quiet on noise. A little playful, very deliberate.';
  const highlights = Array.isArray(src?.highlights) ? src!.highlights! : [];

  return (
    <div className="persona-copy" style={{ color: '#111827' }}>
      <div style={{ fontWeight: 800, fontSize: 18, marginBottom: 8, letterSpacing: 0.2 }}>
        <RichText text={title} />
      </div>
      <div style={{ fontWeight: 600, marginBottom: 8 }}>
        <RichText text={oneLiner} />
      </div>
      <div style={{ opacity: 0.95, marginBottom: 12, lineHeight: 1.7 }}>
        <RichText text={summary} />
      </div>
      {highlights.length > 0 && (
        <div>
          <div style={{ fontWeight: 700, margin: '6px 0 6px' }}>Fortune Notes</div>
          <ul style={{ margin: '0 0 8px 18px', padding: 0, lineHeight: 1.6 }}>
            {highlights.map((h, i) => (
              <li key={i}><RichText text={h} /></li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};

export const PersonaText = memo(PersonaTextBase);
export default PersonaText;
